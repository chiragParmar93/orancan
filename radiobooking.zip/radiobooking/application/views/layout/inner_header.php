<html lang="en" class="no-js">
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8"/>
        <title>Orancan</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>

        <!-- GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet" type="text/css">
        <link href="<?= vendor() ?>/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?= vendor() ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

        <!-- PAGE LEVEL PLUGIN STYLES -->
        <link href="<?= csspath() ?>style.css" rel="stylesheet">
        <link href="<?= csspath() ?>bootstrap.min.css" rel="stylesheet">
        
        <!-- Favicon -->
        <link rel="shortcut icon" href="favicon.ico"/>

        <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    </head>
    <!-- END HEAD -->

    <!-- BODY -->
    <body>

        <!--========== HEADER ==========-->
        <div class="container">
            <div class="header-top">
                <div class="row">
                    <div class="col-sm-6">logo</div>
                    <div class="col-sm-6 pull-right">
                        <ul>
                            <li>test</li>
                            <li>test1</li>
                        </ul>
                    </div>
                </div>
            </div>
            <header class="header">
                <!-- Navbar -->
                <nav class="navbar navbar-inverse navbar-static-top marginBottom-0" role="navigation">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                  
                </div>
                
                <div class="collapse navbar-collapse" id="navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#">Active Link</a></li>
                        <li><a href="#">Link</a></li>
                        <li><a href="#">Dropdown</a></li>
                        <li><a href="#">Dropdown</a></li>
                        <li><a href="#">Dropdown</a></li>
                        <li><a href="#">Dropdown</a></li>

                    </ul>
                </div><!-- /.navbar-collapse -->
            </nav>
                <!-- Navbar -->
            </header>
        </div>
        <!--========== END HEADER ==========-->


        