 <!--========== FOOTER ==========-->
        <footer class="footer"> 
            <!-- Links -->
            
            <!-- End Links -->

            <!-- Copyright -->
            <div class="content container">
                <div class="row">
                    <div class="col-sm-2">
                        <img class="footer-logo" src="<?= imagepath() ?>/logo.png" alt="Acidus Logo">
                    </div>
                    <div class="col-sm-10">
                    
                            <div class="row">
                                <div class="col-sm-2 sm-margin-b-30">
                                    <!-- List -->
                                    <ul class="list-unstyled footer-list">
                                        <li class="footer-list-item"><a href="#">Home</a></li>
                                        <li class="footer-list-item"><a href="#">About</a></li>
                                        <li class="footer-list-item"><a href="#">Work</a></li>
                                        <li class="footer-list-item"><a href="#">Contact</a></li>
                                    </ul>
                                    <!-- End List -->
                                </div>
                                <div class="col-sm-2 sm-margin-b-30">
                                    <!-- List -->
                                    <ul class="list-unstyled footer-list">
                                        <li class="footer-list-item"><a href="#">Twitter</a></li>
                                        <li class="footer-list-item"><a href="#">Facebook</a></li>
                                        <li class="footer-list-item"><a href="#">Instagram</a></li>
                                        <li class="footer-list-item"><a href="#">YouTube</a></li>
                                    </ul>
                                    <!-- End List -->
                                </div>
                                <div class="col-sm-3">
                                    <!-- List -->
                                    <ul class="list-unstyled footer-list">
                                        <li class="footer-list-item"><a href="#">Subscribe to Our Newsletter</a></li>
                                        <li class="footer-list-item"><a href="#">Privacy Policy</a></li>
                                        <li class="footer-list-item"><a href="#">Terms &amp; Conditions</a></li>
                                    </ul>
                                    <!-- End List -->
                                </div>
                        </div>
                    </div>

                </div>
                <!--// end row -->
            </div>
            <!-- End Copyright -->
        </footer>
        <!--========== END FOOTER ==========-->
         <!-- Back To Top -->
        <a href="javascript:void(0);" class="js-back-to-top back-to-top">Top</a>

        <!-- JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
        <!-- CORE PLUGINS -->
        <script src="<?= jspath() ?>jquery-1.11.1.min.js"></script>
        <script src="<?= jspath() ?>bootstrap.min.js"></script>
        
    </body>
    <!-- END BODY -->
</html>