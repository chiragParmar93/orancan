<?php $this->load->view("layout/inner_header"); ?>
<!--Content start By Chirag Parmar 04 April 2018 -->

This is test
<!--End of content -->
<?php $this->load->view("layout/inner_footer"); ?>